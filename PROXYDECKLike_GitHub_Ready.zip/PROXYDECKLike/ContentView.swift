import SwiftUI

struct ContentView: View {
    @State private var proxyEnabled = false
    @State private var dnsEnabled = false
    @State private var host = "127.0.0.1"
    @State private var port = "8080"

    var body: some View {
        NavigationStack {
            Form {
                Section("Connection") {
                    Toggle("Proxy", isOn: $proxyEnabled)
                    Toggle("DNS", isOn: $dnsEnabled)
                }

                Section("Proxy") {
                    TextField("Host", text: $host)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Port", text: $port)
                        .keyboardType(.numberPad)
                }

                Section("Status") {
                    Label(
                        proxyEnabled || dnsEnabled ? "Configured" : "Idle",
                        systemImage: proxyEnabled || dnsEnabled ? "checkmark.circle.fill" : "circle"
                    )
                }
            }
            .navigationTitle("PROXYDECK Like")
        }
    }
}
