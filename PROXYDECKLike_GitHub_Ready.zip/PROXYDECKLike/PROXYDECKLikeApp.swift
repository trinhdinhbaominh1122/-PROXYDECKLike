import SwiftUI

@main
struct PROXYDECKLikeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
